/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  PlusCircle, 
  LayoutGrid, 
  Table as TableIcon, 
  Download, 
  Trash2, 
  CheckCircle2, 
  Search,
  Calendar,
  Tag,
  FileText,
  User,
  Activity,
  ArrowLeft,
  Filter,
  X,
  Pencil
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Expanded Types based on the spreadsheet and screenshot
interface Semovente {
  id: string;
  // Identificação
  processoSei: string;
  nome: string;
  tat: string;
  sexo: 'M' | 'F';
  especie: 'Caprina' | 'Ovina';
  dataNasc: string;
  // Entrada
  atestadoSobrevivencia: string;
  origemNasc: string;
  documentoEntrada: string;
  mesEntradaSiafi: string;
  valorEntrada: string;
  // Saída / Baixa
  termoBaixa: string;
  motivoSaida: string;
  documentoSaida: string;
  mesSaidaSiafi: string;
  numPatrimonial: string;
  outrosDocumentos: string;
  // Metadata
  dataCadastro: string;
}

type View = 'menu' | 'form' | 'list';
type ListMode = 'cards' | 'table';

export default function App() {
  const [view, setView] = useState<View>('menu');
  const [listMode, setListMode] = useState<ListMode>('table');
  const [records, setRecords] = useState<Semovente[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const initialFormState: Omit<Semovente, 'id' | 'dataCadastro'> = {
    processoSei: '',
    nome: '',
    tat: '',
    sexo: 'M',
    especie: 'Caprina',
    dataNasc: '',
    atestadoSobrevivencia: '',
    origemNasc: '',
    documentoEntrada: '',
    mesEntradaSiafi: '',
    valorEntrada: '45,00',
    termoBaixa: '',
    motivoSaida: '',
    documentoSaida: '',
    mesSaidaSiafi: '',
    numPatrimonial: '',
    outrosDocumentos: '',
  };

  const [formData, setFormData] = useState(initialFormState);

  // Load records from localStorage on init
  useEffect(() => {
    const saved = localStorage.getItem('agrofacil_records_v2');
    if (saved) {
      try {
        setRecords(JSON.parse(saved));
      } catch (e) {
        console.error("Erro ao carregar registros", e);
      }
    }
  }, []);

  // Save records to localStorage
  useEffect(() => {
    localStorage.setItem('agrofacil_records_v2', JSON.stringify(records));
  }, [records]);

  const handleSave = () => {
    if (editingId) {
      setRecords(records.map(r => r.id === editingId ? { ...formData, id: editingId, dataCadastro: r.dataCadastro } : r));
    } else {
      const newRecord: Semovente = {
        ...formData,
        id: crypto.randomUUID(),
        dataCadastro: new Date().toISOString(),
      };
      setRecords([newRecord, ...records]);
    }
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setView('list');
    }, 2000);
    setFormData(initialFormState);
    setEditingId(null);
  };

  const handleEdit = (record: Semovente) => {
    setFormData(record);
    setEditingId(record.id);
    setView('form');
  };

  const handleCancel = () => {
    setFormData(initialFormState);
    setEditingId(null);
    setView(editingId ? 'list' : 'menu');
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Tem certeza que deseja apagar este registro?")) {
      setRecords(records.filter(r => r.id !== id));
    }
  };

  const filteredRecords = useMemo(() => {
    if (!searchQuery) return records;
    const q = searchQuery.toLowerCase();
    return records.filter(r => 
      r.nome.toLowerCase().includes(q) || 
      r.tat.toLowerCase().includes(q) || 
      r.processoSei.toLowerCase().includes(q) ||
      r.numPatrimonial.toLowerCase().includes(q)
    );
  }, [records, searchQuery]);

  const exportCSV = () => {
    if (records.length === 0) return;
    
    const headers = Object.keys(records[0]).filter(k => k !== 'id');
    const rows = records.map(r => headers.map(h => {
      const val = (r as any)[h] || '';
      // Escape quotes for CSV by doubling them
      const escapedVal = String(val).replace(/"/g, '""');
      return `"${escapedVal}"`;
    }));
    
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `agrofacil_export_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    // Fix memory leak by revoking the object URL
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen flex flex-col max-w-4xl mx-auto bg-rural-bg shadow-2xl relative overflow-hidden text-rural-text">
      {/* Header */}
      <header className="p-8 pb-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black tracking-tight text-rural-text">Cadastro de Semoventes — CEJHB</h1>
            <p className="text-sm text-rural-muted font-medium mt-1">Caprinos e Ovinos • Conta 115810401 • SIAFI</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => {
                setFormData(initialFormState);
                setEditingId(null);
                setView('form');
              }}
              className={cn(
                "px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2",
                view === 'form' ? "bg-rural-text text-white" : "bg-rural-card text-rural-text border border-rural-border"
              )}
            >
              <PlusCircle className="w-5 h-5" />
              Novo Registro
            </button>
            <button 
              onClick={() => setView('list')}
              className={cn(
                "px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2",
                view === 'list' ? "bg-rural-text text-white" : "bg-rural-card text-rural-text border border-rural-border"
              )}
            >
              <TableIcon className="w-5 h-5" />
              Registros Salvos
              <span className="ml-2 bg-rural-accent/20 text-rural-accent px-2 py-0.5 rounded-full text-xs">
                {records.length}
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 p-8 pt-4 overflow-y-auto">
        <AnimatePresence mode="wait">
          {view === 'menu' && (
            <motion.div 
              key="menu"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8"
            >
              <div className="card-section flex flex-col justify-between h-64 bg-white shadow-sm border border-rural-border">
                <div>
                  <h3 className="text-2xl font-black text-rural-text">Novo Cadastro</h3>
                  <p className="text-rural-muted mt-2">Inicie o registro de um novo animal no sistema.</p>
                </div>
                <button 
                  onClick={() => {
                    setFormData(initialFormState);
                    setEditingId(null);
                    setView('form');
                  }}
                  className="btn-large bg-rural-text text-white w-full"
                >
                  Começar Agora
                </button>
              </div>

              <div className="card-section flex flex-col justify-between h-64 bg-white shadow-sm border border-rural-border">
                <div>
                  <h3 className="text-2xl font-black text-rural-text">Consultar Planilha</h3>
                  <p className="text-rural-muted mt-2">Veja todos os animais cadastrados em formato de tabela.</p>
                </div>
                <button 
                  onClick={() => { setView('list'); setListMode('table'); }}
                  className="btn-large border-2 border-rural-border text-rural-text hover:bg-rural-bg w-full"
                >
                  Abrir Planilha
                </button>
              </div>
            </motion.div>
          )}

          {view === 'form' && (
            <motion.div 
              key="form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-8 pb-32"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-black text-rural-text">{editingId ? 'Editar Registro' : 'Novo Cadastro'}</h2>
              </div>
              {/* Seção 1: Identificação */}
              <section className="card-section space-y-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-rural-muted border-b border-rural-border pb-4">Identificação do Animal</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1">
                    <label className="label-text">Processo SEI — Entrada *</label>
                    <input 
                      className="input-field" 
                      placeholder="Ex: 21165.000904/2020-8"
                      value={formData.processoSei}
                      onChange={e => setFormData({...formData, processoSei: e.target.value})}
                    />
                  </div>
                  <div className="md:col-span-1">
                    <label className="label-text">Nome do Animal *</label>
                    <input 
                      className="input-field" 
                      placeholder="Ex: Funestro"
                      value={formData.nome}
                      onChange={e => setFormData({...formData, nome: e.target.value})}
                    />
                  </div>
                  <div className="md:col-span-1">
                    <label className="label-text">TAT (Nº identificação) *</label>
                    <input 
                      className="input-field" 
                      placeholder="Ex: 20917"
                      value={formData.tat}
                      onChange={e => setFormData({...formData, tat: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="label-text">Sexo *</label>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setFormData({...formData, sexo: 'M'})}
                        className={cn("btn-toggle", formData.sexo === 'M' ? "bg-rural-text text-white border-rural-text" : "border-rural-border text-rural-muted")}
                      >Macho</button>
                      <button 
                        onClick={() => setFormData({...formData, sexo: 'F'})}
                        className={cn("btn-toggle", formData.sexo === 'F' ? "bg-rural-text text-white border-rural-text" : "border-rural-border text-rural-muted")}
                      >Fêmea</button>
                    </div>
                  </div>
                  <div>
                    <label className="label-text">Espécie *</label>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setFormData({...formData, especie: 'Caprina'})}
                        className={cn("btn-toggle", formData.especie === 'Caprina' ? "bg-rural-text text-white border-rural-text" : "border-rural-border text-rural-muted")}
                      >Caprina</button>
                      <button 
                        onClick={() => setFormData({...formData, especie: 'Ovina'})}
                        className={cn("btn-toggle", formData.especie === 'Ovina' ? "bg-rural-text text-white border-rural-text" : "border-rural-border text-rural-muted")}
                      >Ovina</button>
                    </div>
                  </div>
                  <div>
                    <label className="label-text">Data de Nascimento *</label>
                    <input 
                      type="date" 
                      className="input-field"
                      value={formData.dataNasc}
                      onChange={e => setFormData({...formData, dataNasc: e.target.value})}
                    />
                  </div>
                </div>
              </section>

              {/* Seção 2: Entrada */}
              <section className="card-section space-y-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-rural-muted border-b border-rural-border pb-4">Entrada no Sistema</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="label-text">Atestado de Sobrevivência *</label>
                    <input 
                      type="date" 
                      className="input-field"
                      value={formData.atestadoSobrevivencia}
                      onChange={e => setFormData({...formData, atestadoSobrevivencia: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="label-text">Origem / Nascimento *</label>
                    <select 
                      className="input-field"
                      value={formData.origemNasc}
                      onChange={e => setFormData({...formData, origemNasc: e.target.value})}
                    >
                      <option value="">— Selecione —</option>
                      <option value="Area">Area</option>
                      <option value="Compra">Compra</option>
                      <option value="Doação">Doação</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="label-text">Documento de Entrada *</label>
                    <input 
                      className="input-field" 
                      placeholder="Ex: 2020NS002117"
                      value={formData.documentoEntrada}
                      onChange={e => setFormData({...formData, documentoEntrada: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="label-text">Mês de Entrada no SIAFI *</label>
                    <input 
                      type="month" 
                      className="input-field"
                      value={formData.mesEntradaSiafi}
                      onChange={e => setFormData({...formData, mesEntradaSiafi: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="label-text">V.E</label>
                    <input 
                      className="input-field font-mono" 
                      value={formData.valorEntrada}
                      onChange={e => setFormData({...formData, valorEntrada: e.target.value})}
                    />
                    <p className="text-[10px] text-rural-muted mt-1">Valor padrão: 45,00</p>
                  </div>
                </div>
              </section>

              {/* Seção 3: Saída / Baixa */}
              {editingId && (
                <section className="card-section space-y-6">
                  <h3 className="text-xs font-black uppercase tracking-widest text-rural-muted border-b border-rural-border pb-4">Saída / Baixa <span className="normal-case font-normal opacity-50 ml-2">(Preencher somente se o animal saiu)</span></h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="label-text">Termo de Baixa</label>
                      <input 
                        className="input-field" 
                        placeholder="Número do termo"
                        value={formData.termoBaixa}
                        onChange={e => setFormData({...formData, termoBaixa: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label-text">Motivo da Saída</label>
                      <select 
                        className="input-field"
                        value={formData.motivoSaida}
                        onChange={e => setFormData({...formData, motivoSaida: e.target.value})}
                      >
                        <option value="">— Selecione —</option>
                        <option value="Morte">Morte</option>
                        <option value="Venda">Venda</option>
                        <option value="Abate">Abate</option>
                        <option value="Transferência">Transferência</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="label-text">Documento de Saída</label>
                      <input 
                        className="input-field" 
                        placeholder="Nº do documento"
                        value={formData.documentoSaida}
                        onChange={e => setFormData({...formData, documentoSaida: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label-text">Mês de Saída no SIAFI</label>
                      <input 
                        type="month" 
                        className="input-field"
                        value={formData.mesSaidaSiafi}
                        onChange={e => setFormData({...formData, mesSaidaSiafi: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label-text">N.º Patrimonial</label>
                      <input 
                        className="input-field" 
                        placeholder="Número patrimonial"
                        value={formData.numPatrimonial}
                        onChange={e => setFormData({...formData, numPatrimonial: e.target.value})}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="label-text">Outros Documentos</label>
                    <textarea 
                      className="input-field min-h-[100px]" 
                      placeholder="Descreva outros documentos relevantes"
                      value={formData.outrosDocumentos}
                      onChange={e => setFormData({...formData, outrosDocumentos: e.target.value})}
                    />
                  </div>
                </section>
              )}

              <div className="fixed bottom-0 left-0 right-0 p-6 bg-rural-bg/80 backdrop-blur-md border-t border-rural-border z-20">
                <div className="max-w-4xl mx-auto flex gap-4">
                  <button 
                    onClick={handleCancel}
                    className="flex-1 py-4 font-bold text-rural-muted hover:text-rural-text transition-colors"
                  >
                    Cancelar
                  </button>
                  <button 
                    onClick={handleSave}
                    disabled={!formData.nome || !formData.tat || !formData.processoSei}
                    className={cn(
                      "flex-[2] btn-large bg-rural-accent text-white hover:bg-rural-accent/90",
                      (!formData.nome || !formData.tat || !formData.processoSei) && "opacity-30 cursor-not-allowed"
                    )}
                  >
                    {editingId ? 'Atualizar Registro' : 'Salvar Registro'}
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'list' && (
            <motion.div 
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              {/* Toolbar */}
              <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="relative w-full md:w-96">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-rural-muted" />
                  <input 
                    type="text"
                    placeholder="Pesquisar por nome, TAT ou SEI..."
                    className="input-field pl-12 py-3 text-base"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-white/10 rounded-full"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="flex bg-rural-card p-1 rounded-xl border border-rural-border w-full md:w-auto">
                  <button 
                    onClick={() => setListMode('table')}
                    className={cn(
                      "flex-1 md:flex-none px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-all",
                      listMode === 'table' ? "bg-rural-text text-white shadow-sm" : "text-rural-muted hover:text-rural-text"
                    )}
                  >
                    <TableIcon className="w-4 h-4" />
                    Planilha
                  </button>
                  <button 
                    onClick={() => setListMode('cards')}
                    className={cn(
                      "flex-1 md:flex-none px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-all",
                      listMode === 'cards' ? "bg-rural-text text-white shadow-sm" : "text-rural-muted hover:text-rural-text"
                    )}
                  >
                    <LayoutGrid className="w-4 h-4" />
                    Cards
                  </button>
                </div>
              </div>

              {filteredRecords.length === 0 ? (
                <div className="card-section py-20 text-center opacity-30">
                  <Search className="w-16 h-16 mx-auto mb-4" />
                  <p className="text-xl font-bold">Nenhum registro encontrado.</p>
                </div>
              ) : (
                <>
                  {listMode === 'table' ? (
                    <div className="table-container">
                      <table className="rural-table">
                        <thead>
                          <tr>
                            <th>Nome</th>
                            <th>TAT</th>
                            <th>Espécie</th>
                            <th>Sexo</th>
                            <th>Proc. SEI</th>
                            <th>Nascimento</th>
                            <th>Entrada SIAFI</th>
                            <th>Patrimonial</th>
                            <th className="text-center">Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredRecords.map(r => (
                            <tr key={r.id}>
                              <td className="font-bold text-rural-text">{r.nome}</td>
                              <td className="font-mono">{r.tat}</td>
                              <td>
                                <span className={cn(
                                  "px-2 py-0.5 rounded text-[10px] font-black uppercase",
                                  r.especie === 'Caprina' ? "bg-rural-accent/10 text-rural-accent" : "bg-orange-500/10 text-orange-500"
                                )}>
                                  {r.especie}
                                </span>
                              </td>
                              <td>{r.sexo === 'M' ? 'Macho' : 'Fêmea'}</td>
                              <td className="text-xs opacity-70">{r.processoSei}</td>
                              <td>{r.dataNasc ? format(new Date(r.dataNasc), 'dd/MM/yy') : '-'}</td>
                              <td>{r.mesEntradaSiafi || '-'}</td>
                              <td>{r.numPatrimonial || '-'}</td>
                              <td className="text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <button 
                                    onClick={() => handleEdit(r)}
                                    className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors"
                                    title="Editar"
                                  >
                                    <Pencil className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => handleDelete(r.id)}
                                    className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                                    title="Excluir"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filteredRecords.map(record => (
                        <div key={record.id} className="card-section border-l-4 border-rural-accent">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-xl font-black text-rural-text uppercase">{record.nome}</h3>
                              <div className="flex gap-2 mt-1">
                                <span className="text-[10px] font-bold text-rural-accent uppercase tracking-wider">
                                  {record.especie} • {record.sexo === 'M' ? 'Macho' : 'Fêmea'}
                                </span>
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <button 
                                onClick={() => handleEdit(record)}
                                className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors"
                                title="Editar"
                              >
                                <Pencil className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={() => handleDelete(record.id)}
                                className="p-2 text-rural-muted hover:text-red-500 transition-colors"
                                title="Excluir"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                          
                          <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
                            <div>
                              <p className="text-rural-muted uppercase tracking-tighter mb-1">Identificação</p>
                              <p className="font-bold">TAT: {record.tat}</p>
                              <p className="font-bold">SEI: {record.processoSei}</p>
                            </div>
                            <div>
                              <p className="text-rural-muted uppercase tracking-tighter mb-1">Datas</p>
                              <p className="font-bold">Nasc: {record.dataNasc ? format(new Date(record.dataNasc), 'dd/MM/yyyy') : '-'}</p>
                              <p className="font-bold">SIAFI: {record.mesEntradaSiafi || '-'}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}

              <div className="flex justify-center pt-8">
                <button 
                  onClick={exportCSV}
                  disabled={records.length === 0}
                  className="flex items-center gap-2 text-rural-muted hover:text-rural-text transition-colors font-bold uppercase text-xs tracking-widest"
                >
                  <Download className="w-4 h-4" />
                  Baixar Planilha Completa (CSV)
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Success Overlay */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-white/95 text-rural-text p-8 text-center backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="w-24 h-24 bg-rural-accent rounded-full flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(22,163,74,0.3)]">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
              <div className="space-y-2">
                <h2 className="text-4xl font-black uppercase tracking-tighter">Registro Salvo!</h2>
                <p className="text-xl text-rural-muted">A planilha foi atualizada com sucesso.</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="p-8 pt-0 text-center">
        <div className="h-px bg-rural-border w-full mb-4 opacity-50" />
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-rural-muted opacity-30">
          AgroFácil v2.0 • Controle de Ativos SIAFI • CEJHB
        </p>
      </footer>
    </div>
  );
}
